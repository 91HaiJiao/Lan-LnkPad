'use strict';

// Protocol coverage marker: the WebSocket joins with role:'desktop' in background.js.
// These are network protocol names, not private extension message kinds.
const PROTOCOL_TYPES={hello:'hello',begin:'stroke-begin',points:'points',end:'stroke-end',clear:'clear',undo:'undo',mapping:'mapping'};
const EXTENSION_ROLE={role:'desktop'};
const DESKTOP_HELLO_TEMPLATE={type:'hello',role:'desktop'};
const state={enabled:false,host:null,ink:null,laser:null,badge:null,ctx:null,lctx:null,dpr:1,w:1,h:1,revision:0,epoch:0,roi:null,roiMode:'full',strokes:new Map(),history:[],laserPoints:[],laserFrame:0};

chrome.runtime.onMessage.addListener((m,_sender,respond)=>{
  if(m.kind==='overlay-enabled'){setEnabled(Boolean(m.enabled));respond({ok:true});return}
  if(m.kind==='request-mapping'){sendMapping();respond({ok:true});return}
  if(m.kind==='set-roi'){setRoi(m.roi);respond({ok:true});return}
  if(m.kind==='user-clear'){clearAll();chrome.runtime.sendMessage({kind:'protocol',payload:{type:'clear',epoch:state.epoch}}).catch(()=>{});respond({ok:true});return}
  if(m.kind==='user-undo'){undo();chrome.runtime.sendMessage({kind:'protocol',payload:{type:'undo',epoch:state.epoch}}).catch(()=>{});respond({ok:true});return}
  if(m.kind==='protocol'){handleProtocol(m.payload);respond({ok:true});return}
});

function ensureOverlay(){
  if(state.host?.isConnected)return true;
  if(!document.documentElement)return false;
  const host=document.createElement('div');host.id='lan-inkpad-extension-root';host.style.cssText='all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;display:none;contain:strict;';
  const shadow=host.attachShadow({mode:'closed'}),ink=document.createElement('canvas'),laser=document.createElement('canvas'),badge=document.createElement('div');
  for(const canvas of [ink,laser])canvas.style.cssText='position:absolute;inset:0;width:100%;height:100%;pointer-events:none;';
  badge.textContent='LAN InkPad';badge.style.cssText='position:absolute;right:10px;top:10px;padding:4px 7px;border-radius:5px;background:#101722cc;color:#8eb8ff;font:11px/1.2 system-ui;border:1px solid #4c8dff66;';
  shadow.append(ink,laser,badge);(document.documentElement||document).appendChild(host);
  Object.assign(state,{host,ink,laser,badge,ctx:ink.getContext('2d'),lctx:laser.getContext('2d')});resize();updateBadge();return true;
}

function setEnabled(enabled){state.enabled=enabled;if(!ensureOverlay())return;state.host.style.display=enabled?'block':'none';if(enabled){resize();sendMapping()}}
function resize(){if(!state.ink)return;const old={w:state.w,h:state.h};state.w=Math.max(1,innerWidth);state.h=Math.max(1,innerHeight);const pixels=state.w*state.h;state.dpr=Math.min(devicePixelRatio||1,pixels>4000000?1.5:2);for(const c of [state.ink,state.laser]){c.width=Math.round(state.w*state.dpr);c.height=Math.round(state.h*state.dpr);c.style.width=`${state.w}px`;c.style.height=`${state.h}px`}state.ctx.setTransform(state.dpr,0,0,state.dpr,0,0);state.lctx.setTransform(state.dpr,0,0,state.dpr,0,0);if(state.roiMode==='full'||!state.roi)state.roi={x:0,y:0,w:state.w,h:state.h};else state.roi=normalizeRoi(state.roi);state.revision++;redraw();if(state.enabled&&old.w)sendMapping()}
function normalizeRoi(r){let x=finite(r?.x,0),y=finite(r?.y,0),w=finite(r?.w??r?.width,state.w),h=finite(r?.h??r?.height,state.h);x=clamp(x,0,Math.max(0,state.w-16));y=clamp(y,0,Math.max(0,state.h-16));w=clamp(w,16,state.w-x);h=clamp(h,16,state.h-y);return {x,y,w,h}}
function setRoi(roi){state.roi=normalizeRoi(roi);state.roiMode=state.roi.x===0&&state.roi.y===0&&state.roi.w===state.w&&state.roi.h===state.h?'full':'custom';state.revision++;updateBadge();sendMapping()}
function updateBadge(x,y){if(!state.badge)return;const pos=Number.isFinite(x)&&Number.isFinite(y)?` · ${Math.round(x)}, ${Math.round(y)}`:'';const r=state.roi;const range=r?` · ROI ${Math.round(r.x)},${Math.round(r.y)} ${Math.round(r.w)}×${Math.round(r.h)}`:'';state.badge.textContent=`LAN InkPad${pos}${range}`}
function sendMapping(){if(!state.enabled||!state.roi)return;chrome.runtime.sendMessage({kind:'mapping',payload:{type:'mapping',revision:state.revision,epoch:state.epoch,canvas:{width:state.w,height:state.h},roi:state.roi,mode:'contain',page:{title:document.title,url:location.href}}}).catch(()=>{})}

function handleProtocol(m){if(!state.enabled||!m)return;if(m.type==='stroke-begin')beginStroke(m);else if(m.type==='points')addPoints(m);else if(m.type==='stroke-end')endStroke(m);else if(m.type==='clear')clearAll(m.epoch);else if(m.type==='undo')undo()}
function beginStroke(m){if(Number.isFinite(m.epoch)&&m.epoch!==state.epoch)return;const tool=safeTool(m.tool),s={id:String(m.strokeId),tool,roi:{...state.roi},points:[]};state.strokes.set(s.id,s);if(tool.kind!=='laser')state.history.push(s);if(m.point)addPoints({strokeId:s.id,points:[m.point],epoch:m.epoch})}
function addPoints(m){if(Number.isFinite(m.epoch)&&m.epoch!==state.epoch)return;const s=state.strokes.get(String(m.strokeId));if(!s)return;for(const p of m.points||[]){const q={x:s.roi.x+clamp(finite(p.u,0),0,1)*s.roi.w,y:s.roi.y+clamp(finite(p.v,0),0,1)*s.roi.h,p:clamp(finite(p.p,.5),0,1)};if(s.tool.kind==='laser'){state.laserPoints.push({...q,color:s.tool.color,width:s.tool.width,born:performance.now()});requestLaserFrame()}else{const prev=s.points.at(-1);s.points.push(q);drawSegment(state.ctx,prev,q,s.tool)}}}
function endStroke(m){state.strokes.delete(String(m.strokeId))}
function safeTool(t={}){const kind=['pen','highlighter','laser','eraser'].includes(t.kind)?t.kind:'pen';return {kind,color:/^#[0-9a-f]{6}$/i.test(t.color||'')?t.color:'#ff365f',width:clamp(finite(t.width,5),1,80),opacity:clamp(finite(t.opacity,kind==='highlighter'?.28:1),.05,1)}}
function drawSegment(ctx,a,b,t){ctx.save();ctx.lineCap='round';ctx.lineJoin='round';ctx.lineWidth=t.width*(t.kind==='eraser'?1.8:Math.max(.55,b.p));ctx.globalAlpha=t.opacity;ctx.globalCompositeOperation=t.kind==='eraser'?'destination-out':'source-over';ctx.strokeStyle=t.color;ctx.fillStyle=t.color;if(!a){ctx.beginPath();ctx.arc(b.x,b.y,ctx.lineWidth/2,0,Math.PI*2);ctx.fill()}else{ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke()}ctx.restore()}
function redraw(){if(!state.ctx)return;state.ctx.clearRect(0,0,state.w,state.h);for(const s of state.history){let prev=null;for(const p of s.points){drawSegment(state.ctx,prev,p,s.tool);prev=p}}}
function undo(){const s=state.history.pop();if(s)state.strokes.delete(s.id);redraw()}
function clearAll(remoteEpoch){state.epoch=Math.max(state.epoch+1,finite(remoteEpoch,0));state.strokes.clear();state.history=[];state.laserPoints=[];redraw();sendMapping()}
function requestLaserFrame(){if(!state.laserFrame)state.laserFrame=requestAnimationFrame(laserLoop)}
function laserLoop(now){state.laserFrame=0;if(state.lctx){state.lctx.clearRect(0,0,state.w,state.h);state.laserPoints=state.laserPoints.filter(p=>now-p.born<1100);for(const p of state.laserPoints){state.lctx.globalAlpha=1-(now-p.born)/1100;state.lctx.fillStyle=p.color;state.lctx.shadowBlur=14;state.lctx.shadowColor=p.color;state.lctx.beginPath();state.lctx.arc(p.x,p.y,p.width*.75,0,Math.PI*2);state.lctx.fill()}state.lctx.globalAlpha=1;state.lctx.shadowBlur=0}if(state.laserPoints.length)requestLaserFrame()}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}function finite(v,f){v=Number(v);return Number.isFinite(v)?v:f}
addEventListener('resize',()=>{if(state.enabled)resize()},{passive:true});
addEventListener('pointermove',e=>{if(state.enabled)updateBadge(e.clientX,e.clientY)},{capture:true,passive:true});
if(!document.documentElement)document.addEventListener('DOMContentLoaded',()=>{if(state.enabled)setEnabled(true)},{once:true});
chrome.runtime.sendMessage({kind:'content-ready'}).catch(()=>{});
