'use strict';

const DEFAULTS={host:'localhost:8787',room:'',enabledTabs:{},roi:null};
let config={...DEFAULTS},ws=null,reconnectTimer=null,pingTimer=null,status='disconnected';
const strokeTabs=new Map();

chrome.runtime.onInstalled.addListener(async()=>{
  const saved=await chrome.storage.local.get(DEFAULTS);
  if(!saved.room)saved.room=randomRoom();
  await chrome.storage.local.set(saved);
  config=saved;
});

chrome.runtime.onStartup.addListener(loadAndConnect);
chrome.tabs.onActivated.addListener(({tabId})=>activateTab(tabId));
chrome.tabs.onUpdated.addListener((tabId,change)=>{if(change.status==='complete')activateTab(tabId)});
chrome.tabs.onRemoved.addListener(async tabId=>{for(const [strokeId,routedTab] of strokeTabs)if(routedTab===tabId)strokeTabs.delete(strokeId);if(config.enabledTabs?.[tabId]){delete config.enabledTabs[tabId];await chrome.storage.local.set({enabledTabs:config.enabledTabs})}});

chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  handleInternal(message,sender).then(sendResponse).catch(error=>sendResponse({ok:false,error:error.message}));
  return true;
});

async function loadAndConnect(){config=await chrome.storage.local.get(DEFAULTS);if(config.room)connect();}

async function handleInternal(m,sender){
  if(!m||typeof m.kind!=='string')return {ok:false};
  if(m.kind==='get-state')return {...publicState(),tabEnabled:sender.tab?Boolean(config.enabledTabs?.[sender.tab.id]):undefined};
  if(m.kind==='configure'){
    config.host=normalizeHost(m.host);config.room=normalizeRoom(m.room);
    await chrome.storage.local.set({host:config.host,room:config.room});connect();return publicState();
  }
  if(m.kind==='new-room'){config.room=randomRoom();await chrome.storage.local.set({room:config.room});connect();return publicState()}
  if(m.kind==='toggle-tab'){
    const tabId=Number(m.tabId);if(!Number.isInteger(tabId))throw new Error('无效标签页');
    config.enabledTabs={...(config.enabledTabs||{}),[tabId]:Boolean(m.enabled)};
    if(!m.enabled)delete config.enabledTabs[tabId];
    await chrome.storage.local.set({enabledTabs:config.enabledTabs});
    await safeTabMessage(tabId,{kind:'overlay-enabled',enabled:Boolean(m.enabled)});
    if(m.enabled)await requestMapping(tabId);return publicState();
  }
  if(m.kind==='content-ready'&&sender.tab){const enabled=Boolean(config.enabledTabs?.[sender.tab.id]);await safeTabMessage(sender.tab.id,{kind:'overlay-enabled',enabled});if(enabled)await requestMapping(sender.tab.id);return {ok:true}}
  if(m.kind==='mapping'&&sender.tab){if(await isActiveEnabled(sender.tab.id))sendProtocol(m.payload);return {ok:true}}
  if(m.kind==='protocol'){sendProtocol(m.payload);return {ok:true}}
  if(m.kind==='clear-active'||m.kind==='undo-active'){const tab=await activeTab();if(tab&&config.enabledTabs?.[tab.id])await safeTabMessage(tab.id,{kind:m.kind==='clear-active'?'user-clear':'user-undo'});return {ok:true}}
  return {ok:false};
}

function connect(){
  clearTimeout(reconnectTimer);clearInterval(pingTimer);if(ws){ws.onclose=null;ws.close();ws=null}
  if(!config.host||!config.room){setStatus('disconnected');return}
  setStatus('connecting');
  const scheme=config.host.startsWith('localhost')||/^127\./.test(config.host)?'ws':'ws';
  ws=new WebSocket(`${scheme}://${config.host}/ws?room=${config.room}&role=desktop&clientId=browser-extension`);
  ws.onopen=()=>{setStatus('waiting');pingTimer=setInterval(()=>sendProtocol({type:'ping',nonce:Date.now()}),20000);pushActiveMapping()};
  ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch{return}handleProtocol(m)};
  ws.onclose=()=>{clearInterval(pingTimer);setStatus('disconnected');reconnectTimer=setTimeout(connect,1500)};
  ws.onerror=()=>setStatus('error');
}

async function handleProtocol(m){
  if(m.type==='peer-joined'&&m.role==='mobile')setStatus('connected');
  else if(m.type==='peer-left'&&m.role==='mobile')setStatus('waiting');
  else if(m.type==='room-state')setStatus(m.peerConnected?'connected':'waiting');
  if(['stroke-begin','points','stroke-end'].includes(m.type)){
    let tabId=strokeTabs.get(String(m.strokeId));
    if(m.type==='stroke-begin'){
      const tab=await activeTab();tabId=tab&&config.enabledTabs?.[tab.id]?tab.id:null;
      if(tabId!=null)strokeTabs.set(String(m.strokeId),tabId);
    }
    if(tabId!=null)await safeTabMessage(tabId,{kind:'protocol',payload:m});
    if(m.type==='stroke-end')strokeTabs.delete(String(m.strokeId));
  }else if(m.type==='clear'||m.type==='undo'){
    const tab=await activeTab();if(tab&&config.enabledTabs?.[tab.id])await safeTabMessage(tab.id,{kind:'protocol',payload:m});
  }else if(m.type==='set-roi-request'){
    const tab=await activeTab();if(tab&&config.enabledTabs?.[tab.id])await safeTabMessage(tab.id,{kind:'set-roi',roi:m.roi});
  }
}

function sendProtocol(payload){if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify(payload))}
async function activeTab(){const [tab]=await chrome.tabs.query({active:true,currentWindow:true});return tab}
async function isActiveEnabled(tabId){const tab=await activeTab();return tab?.id===tabId&&Boolean(config.enabledTabs?.[tabId])}
async function activateTab(tabId){if(config.enabledTabs?.[tabId])await requestMapping(tabId)}
async function requestMapping(tabId){await safeTabMessage(tabId,{kind:'request-mapping'})}
async function pushActiveMapping(){const tab=await activeTab();if(tab&&config.enabledTabs?.[tab.id])await requestMapping(tab.id)}
async function safeTabMessage(tabId,message){try{return await chrome.tabs.sendMessage(tabId,message)}catch{return null}}
function setStatus(next){status=next;chrome.runtime.sendMessage({kind:'status-changed',state:publicState()}).catch(()=>{})}
function publicState(){return {host:config.host,room:config.room,status,enabledTabs:config.enabledTabs||{}}}
function normalizeHost(v){return String(v||'').trim().replace(/^https?:\/\//,'').replace(/^wss?:\/\//,'').replace(/\/$/,'')}
function normalizeRoom(v){const room=String(v||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);if(room.length!==6)throw new Error('配对码必须为 6 位');return room}
function randomRoom(){return String(Math.floor(100000+Math.random()*900000))}
loadAndConnect();
