'use strict';
const $=id=>document.getElementById(id);let activeTab=null;
async function init(){[activeTab]=await chrome.tabs.query({active:true,currentWindow:true});const s=await chrome.runtime.sendMessage({kind:'get-state'});$('host').value=s.host||'';$('room').value=s.room||'';$('enabled').checked=Boolean(s.enabledTabs?.[activeTab?.id]);renderStatus(s.status);const restricted=!activeTab?.url||!/^https?:/i.test(activeTab.url);$('enabled').disabled=restricted;if(restricted)$('pageHint').textContent='当前是浏览器受保护页面，扩展不能在此页面注入标注层。'}
function renderStatus(s){const map={connected:'手机已连接',waiting:'等待手机',connecting:'连接中',error:'连接错误',disconnected:'未连接'};$('status').textContent=map[s]||s;$('status').classList.toggle('connected',s==='connected')}
$('connect').onclick=async()=>{const s=await chrome.runtime.sendMessage({kind:'configure',host:$('host').value,room:$('room').value});renderStatus(s.status)};
$('newRoom').onclick=async()=>{const s=await chrome.runtime.sendMessage({kind:'new-room'});$('room').value=s.room;renderStatus(s.status)};
$('enabled').onchange=async e=>{if(activeTab)await chrome.runtime.sendMessage({kind:'toggle-tab',tabId:activeTab.id,enabled:e.target.checked})};
$('undo').onclick=()=>chrome.runtime.sendMessage({kind:'undo-active'});$('clear').onclick=()=>chrome.runtime.sendMessage({kind:'clear-active'});
chrome.runtime.onMessage.addListener(m=>{if(m.kind==='status-changed')renderStatus(m.state.status)});init();
